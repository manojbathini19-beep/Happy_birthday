GITHUB PAGES DEPLOYMENT

1. Extract this ZIP file.
2. Open your GitHub repository.
3. Upload index.html to the ROOT of the repository (not inside another folder).
4. Commit the changes.
5. Open Settings > Pages.
6. Under Build and deployment, select "Deploy from a branch".
7. Select branch "main" and folder "/ (root)", then Save.
8. Wait a few minutes and open your GitHub Pages URL.

The photos are embedded directly in index.html, so no separate images folder is required.

If your repository is a project repository (not named bathini19-beep.github.io), its URL normally includes the repository name:
https://bathini19-beep.github.io/REPOSITORY-NAME/
